<!DOCTYPE html>
<html lang="tr-TR">

<head>
    <?php require_once 'assets/include/Head.php' ?>
    <title>Hata - 404</title>
</head>
<style>
    .container {
        height: calc(100% - 64px);
    }
    .container .row {
        height: calc(100% - 64px);
    }
    .container .row .col-md-12 h1 {
        color: #333;
        font-size: 2em;
        margin-top: 1.5em;
        text-align: center;
    }
    .container .row .col-md-12 {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }
    .container .row .col-md-12 img {
        width: 100%;
        max-width: 50%;
    }
    @media screen and (max-width: 768px){
        .container .row .col-md-12 img {
            max-width: 85%;
        }
        .container .row .col-md-12 h1 {
            font-size: 1.6em;
        }
    }
</style>
<body>
    <?php require_once 'assets/include/Header.php' ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <img src="assets/images/icon/page_not_found.svg" alt="">
                <h1>Sayfa kaldırılmış veya değiştirilmiş olabilir.</h1>
            </div>
        </div>
    </div>
    <?php require_once 'assets/include/Script.php' ?>
</body>

</html>