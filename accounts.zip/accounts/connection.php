$host = '"localhost";';
$database = '"emirha22_email_service";';
$user = '"emirha22_emirhankayabas";';
$password = '"emirhanemre123";';

try {
    $db = new PDO("mysql:host=$host;dbname=$database;charset=utf8", $user, $password);
} catch (PDOException $e) {
    die($e->getMessage());
}