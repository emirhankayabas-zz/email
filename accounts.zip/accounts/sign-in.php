﻿<!-- sign in - oturum aç -->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="tr-TR">

<head>
    <?php require_once '../assets/include/Head.php' ?>
    <title>Oturum açın</title>
</head>

<body>
    <main class="login">
        <div class="container">
            <div class="login-container">
                <div class="login-content">
                    <header class="login-header">
                        <div class="login-logo">
                            <img src="../assets/images/email-64.png" alt="">
                        </div>
                        <div class="login-title">
                            <h1>Oturum aç</h1>
                            <span>Emirhan'a devam et</span>
                        </div>
                    </header>
                    <main class="login-main">
                        <form action="sign-in-ht.php" class="login-form" id="loginForm" autocomplete="off" novalidate enctype="multipart/form-data">
                            <ul>
                                <li class="w-100 mt-2 d-inline-block">
                                    <label>E-posta</label>
                                    <input type="email" name="userEmail" required />
                                    <div class="error-svg">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#FA3F3F">
                                            <path d="M23 10.586L13.414 1c-.781-.781-2.047-.781-2.828 0L1 10.587c-.781.781-.781 2.047 0 2.828L10.586 23c.781.781 2.047.781 2.828 0L23 13.415c.781-.781.781-2.047 0-2.829zM11.068 6.417c0-.552.448-1 1-1s1 .448 1 1v6c0 .552-.448 1-1 1s-1-.448-1-1v-6zm1.051 11.51h-.028c-.819-.003-1.49-.651-1.522-1.47-.031-.814.605-1.499 1.419-1.529l.029-.001h.028c.82.002 1.491.651 1.522 1.47.031.814-.605 1.499-1.419 1.529l-.029.001z"></path>
                                        </svg>
                                    </div>
                                </li>
                                <li class="w-100 mt-2 d-inline-block">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <label>Şifre</label>
                                        <a href="fargot-password" class="icon mr-5" data-bs-toggle="tooltip" data-bs-placement="right" title="Şifremi unuttum">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
                                                <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z" />
                                            </svg>
                                        </a>
                                    </div>
                                    <input type="password" name="userPassword" id="passwordInputLogin" minlength="8" maxlength="20" required />
                                    <div class="error-svg">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#FA3F3F">
                                            <path d="M23 10.586L13.414 1c-.781-.781-2.047-.781-2.828 0L1 10.587c-.781.781-.781 2.047 0 2.828L10.586 23c.781.781 2.047.781 2.828 0L23 13.415c.781-.781.781-2.047 0-2.829zM11.068 6.417c0-.552.448-1 1-1s1 .448 1 1v6c0 .552-.448 1-1 1s-1-.448-1-1v-6zm1.051 11.51h-.028c-.819-.003-1.49-.651-1.522-1.47-.031-.814.605-1.499 1.419-1.529l.029-.001h.028c.82.002 1.491.651 1.522 1.47.031.814-.605 1.499-1.419 1.529l-.029.001z"></path>
                                        </svg>
                                    </div>
                                </li>
                                <div class="checkbox-container">
                                    <div class="d-inline-flex">
                                        <input type="checkbox" id="renemberLogin"><label for="renemberLogin">Şifreyi göster</label>
                                    </div>
                                    <a href="sign-up" class="d-inline-block">Hesap oluşturun</a>
                                </div>
                                <button type="submit" class="btn btn-custom">Oturum aç</button>
                            </ul>
                        </form>
                    </main>
                </div>
            </div>
        </div>
    </main>
    <?php require_once '../assets/include/Script.php' ?>
    <script>
        var tooltipTriggerList = [].slice.call(
            document.querySelectorAll('[data-bs-toggle="tooltip"]')
        );
        var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
    <script>
        const loginForm = document.getElementById("loginForm");
        loginForm.watchValidate();

        loginForm.addEventListener("submit", function(e) {
            e.preventDefault();
            this.validate();
            this.sendIfIsValid();
        });

        loginForm.getResult(function(response) {
            //console.log(response.currentTarget.response);
            window.location = "../mail/index";
        });

        let renemberLogin = document.getElementById("renemberLogin"),
        passwordInputLogin = document.getElementById("passwordInputLogin");

        function tooglePassword() {
            if (passwordInputLogin.type === "password") {
                passwordInputLogin.type = "text";
            } else {
                passwordInputLogin.type = "password";
            }
        }

        renemberLogin.addEventListener("click", tooglePassword);
    </script>
</body>

</html>