<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../assets/vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    $Host = 'mail.emirhanturizm.online';
    $Username = 'emirhankayabas@emirhanturizm.online';
    $Password = "emirhanemre123";

    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->isSMTP();
    $mail->Host = $Host;
    $mail->SMTPAuth = true;
    $mail->Username = $Username;
    $mail->Password = $Password;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->CharSet = 'UTF-8';

    //Recipients
    $mail->setFrom($Username, 'Emirhan Kayabaş');
    $mail->addAddress($userEmail, $userName . " " . $userSurname);

    //Content
    $mail->isHTML(true);
    $mail->Subject = 'Hesabınız başarıyla oluşturulmuştur. - Emirhan';
    //$mail->Body = "Merhaba $userName . $userSurname. Kayıt olduğunuz için teşekkür ederiz. Hesabınızı doğrulamak için <a href='confirmation.php'>Tıkla</a>";
    $mail->Body = "
        <center><img src='https://emirhanturizm.online/email_service/demo/assets/images/email-64.png'></center><br>
        <center><h2>Emirhan Mail</h2></center> <br>
        Ad ve soyad: $userName $userSurname; <br>
        E-posta: $userEmail; <br> <br>
        Üye olduğunuz için teşekkürler. <br>
        Hesabınızı doğrulamak için <a>Şimdilik Devre dışı<a/>
    ";
    $mail->send();
    echo "mail başaralı";
} catch (Exception $e) {
    echo "Mesaj gönderilemedi. Posta Hatası: {$mail->ErrorInfo}";
}
