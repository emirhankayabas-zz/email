<?php
require_once 'connection.php';
if ($_POST) {
    $userName = htmlspecialchars(ucwords(trim($_POST["userName"])));
    $userSurname = htmlspecialchars(ucwords(trim($_POST["userSurname"])));
    $userEmail = htmlspecialchars(trim($_POST['userEmail']));
    $userPassword = htmlspecialchars(trim(md5($_POST['userPassword'])));

    if (empty($userName) || empty($userSurname) || empty($userEmail) || empty($userPassword)) {
        echo "Lütfen Boş Bırakmayın";
    } else {
        if (filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
            $query = $db->prepare("INSERT INTO users SET
            userName = ?,
            userSurname = ?,
            userEmail = ?,
            userPassword = ?");
            $insert = $query->execute(array(
                $userName, $userSurname, $userEmail, $userPassword
            ));
            include './email-tamplate.php';
        } else {
            echo ("$userEmail geçersiz bir eposta");
        }
    }
} else {
    header("Location: ../error.php");
    echo "POST YOK MALASEF";
}
