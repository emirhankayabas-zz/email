<?php
session_start();
require_once 'connection.php';

if ($_POST) {
    $userEmail = htmlspecialchars(trim($_POST['userEmail']));
    $userPassword = htmlspecialchars(trim(md5($_POST['userPassword'])));

    if (empty($userEmail) || empty($userPassword)) {
        echo "Boş bırakmayın";
    } else {
        if (filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
            $query = $db->prepare("SELECT * FROM users WHERE userEmail = ? AND userPassword = ?");
            $query->execute(array($userEmail, $userPassword));
            $user = $query->fetch();

            if ($query->rowCount()) {
                //$_SESSION["userEmail"] = $userEmail;
                $_SESSION['user'] = $user;
            } else {
                echo "Böyle bir kullanıcı yok";
            }
        } else {
            echo "$userEmail geçerli bir eposta değil.";
        }
    }
} else {
    echo "POST MALASEF YOK";
    die();
}
