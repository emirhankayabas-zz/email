HTMLElement.prototype.validate = function () {
  [...this.elements].forEach((formElement) => {
    formElement.isValidElement();
  });
};

HTMLElement.prototype.watchValidate = function () {
  [...this.elements].forEach((formElement) => {
    ["change", "keyup"].forEach((methot) => {
      formElement.addEventListener(methot, () => {
        formElement.isValidElement();
      });
    });
  });
};

HTMLElement.prototype.isValidElement = function () {
  let parent = this;
  if (
    this.getAttribute("type") == "radio" ||
    this.getAttribute("type") == "checkbox"
  ) {
    parent =
      this.closest(".checkbox-container") || this.closest(".radio-container");
  }
  if (!this.checkValidity()) {
    this.closest("li").classList.add("error-li");
    if (parent.nextElementSibling?.className !== "error") {
      const error = document.createElement("small");
      error.className = "error";
      error.innerText = this.validationMessage;
      parent.insertAdjacentElement("afterend", error);
    } else {
      parent.nextElementSibling.innerText = this.validationMessage;
    }
  } else {
    this.closest("li")?.classList.remove("error-li");
    if (parent.nextElementSibling?.className == "error") {
      parent.nextElementSibling.remove();
    }
  }
};

HTMLElement.prototype.sendIfIsValid = function () {
  if (this.checkValidity()) {
    new FormData(this);
  }
};

HTMLElement.prototype.getResult = function (callback) {
  this.addEventListener("formdata", (e) => {
    const data = e.formData;
    var request = new XMLHttpRequest();
    request.open("POST", this.action);
    // request.addEventListener("load", function (response) {
    //   console.log(response.currentTarget.response);
    // });
    request.addEventListener("load", callback);
    request.send(data);
  });
};
