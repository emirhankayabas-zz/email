const form = document.getElementById("registerForm");
form.watchValidate();

form.addEventListener("submit", function (e) {
  e.preventDefault();
  this.validate();
  this.sendIfIsValid();
});

form.getResult(function (response) {
  //console.log(response.currentTarget.response);
  window.location = "./sign-in";
});

let renember = document.getElementById("renember"),
  passwordInput = document.getElementById("passwordInput");

function tooglePassword() {
  if (passwordInput.type === "password") {
    passwordInput.type = "text";
  } else {
    passwordInput.type = "password";
  }
}

renember.addEventListener("click", tooglePassword);