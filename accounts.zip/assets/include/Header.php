<div class="stick">
    <header class="header border-mobil">
        <nav class="nav">
            <a href="./" class="brand">
                <div class="logo">
                    <img src="assets/images/email-512.png" alt="">
                    <span>Emirhan</span>
                </div>
            </a>
            <div class="menu">
                <ul>
                    <li>
                        <a href="accounts/sign-in" class="btn" title="Oturum aç">Oturum aç</a>
                    </li>
                    <li>
                        <a href="accounts/sign-up" class="btn btn-custom" title="Hesap oluşturun">Hesap oluşturun</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <header class="mobil">
        <nav class="mobil">
            <div class="menu">
                <ul>
                    <li>
                        <a href="accounts/sign-in" class="btn" title="Oturum aç">Oturum aç</a>
                    </li>
                    <li>
                        <a href="accounts/sign-up" class="btn" title="Hesap oluşturun">Hesap oluşturun</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
</div>