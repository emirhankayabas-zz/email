<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- CSS Only -->
<link rel="stylesheet" href="assets/css/reset.css" />
<link rel="stylesheet" href="assets/css/bootstrap/bootstrap.min.css" />
<link rel="stylesheet" href="assets/css/index.css" />

<link rel="stylesheet" href="../assets/css/reset.css" />
<link rel="stylesheet" href="../assets/css/bootstrap/bootstrap.min.css" />
<link rel="stylesheet" href="../assets/css/index.css" />

<!-- FontFont Awesome -->
<script src="https://kit.fontawesome.com/4307e5bbcc.js" crossorigin="anonymous"></script>

<!-- Favicon Icon -->
<link rel="shortcut icon" href="assets/images/email-256.png" type="image/x-icon" />
<link rel="icon" href="assets/images/email-16.png" sizes="16x16" />
<link rel="icon" href="assets/images/email-24.png" sizes="24x24" />
<link rel="icon" href="assets/images/email-32.png" sizes="32x32" />
<link rel="icon" href="assets/images/email-64.png" sizes="64x64" />
<link rel="icon" href="assets/images/email-128.png" sizes="128x128" />
<link rel="icon" href="assets/images/email-256.png" sizes="256x256" />
<link rel="icon" href="assets/images/email-512.png" sizes="512x512" />

<link rel="shortcut icon" href="assets/images/email-256.png" type="image/x-icon" />
<link rel="icon" href="../assets/images/email-16.png" sizes="16x16" />
<link rel="icon" href="../assets/images/email-24.png" sizes="24x24" />
<link rel="icon" href="../assets/images/email-32.png" sizes="32x32" />
<link rel="icon" href="../assets/images/email-64.png" sizes="64x64" />
<link rel="icon" href="../assets/images/email-128.png" sizes="128x128" />
<link rel="icon" href="../assets/images/email-256.png" sizes="256x256" />
<link rel="icon" href="../assets/images/email-512.png" sizes="512x512" />