<!DOCTYPE html>
<html lang="tr-TR">

<head>
    <?php require_once 'assets/include/Head.php'; ?>
    <title>Anasayfa</title>
</head>

<body>
    <?php require_once 'assets/include/Header.php' ?>

    <main class="main">
        <div class="container-fluid">
            <div class="container">
                <div class="row landing-page">
                    <div class="col-md-6">
                        <div class="content">
                            <div class="content-title">
                                <h1>Emirhan ile daha fazlasını yapın</h1>
                            </div>
                            <div class="content-copy">
                                <p>Evde, hareket halinde veya istediğiniz yerde en verimli şekilde çalışmanız ve bağlı kalmanız için gereken her şey.</p>
                            </div>
                            <a href="accounts/sign-up" class="btn btn-custom" title="Hesap oluşturun">Hesap oluşturun</a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <img src="assets/images/icon/hey_email_liaa.svg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php require_once 'assets/include/Script.php' ?>
</body>

</html>