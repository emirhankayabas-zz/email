<?php
session_start();

if ($_SESSION) {
?>
    <!DOCTYPE html>
    <html lang="tr-TR">

    <head>
        <?php require_once '../assets/include/Head.php' ?>
        <title>Mail Sayfası</title>
    </head>

    <body>
        <header class="mail w-100">
            <nav class="mail-bar w-100 d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center justify-content-between w-100">
                    <div class="start">
                        <div class="icon list" id="menuOpen" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Menu">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
                            </svg>
                        </div>
                        <a href="./" class="logo">
                            <img src="../assets/images/email-64.png" alt="">
                            <span>Emirhan</span>
                        </a>
                    </div>
                    <div class="center">
                        <form action="">
                            <input type="text" id="searchInput" name="search" placeholder="Posta ara">
                            <span class="search-icon" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Arama">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                                </svg>
                            </span>
                        </form>
                        <div class="result" id="result">
                            <ul>
                                <li class="result-item"><a href="#">Emirhan Turizm</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="end">
                        <div class="icon supoort" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Destek">
                            <svg class="t7" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="#000000" focusable="false">
                                <path fill="none" d="M0 0h24v24H0z"></path>
                                <path d="M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"></path>
                            </svg>
                        </div>
                        <div class="icon setting" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ayarlar">
                            <svg class="Xy" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                <path d="M13.85 22.25h-3.7c-.74 0-1.36-.54-1.45-1.27l-.27-1.89c-.27-.14-.53-.29-.79-.46l-1.8.72c-.7.26-1.47-.03-1.81-.65L2.2 15.53c-.35-.66-.2-1.44.36-1.88l1.53-1.19c-.01-.15-.02-.3-.02-.46 0-.15.01-.31.02-.46l-1.52-1.19c-.59-.45-.74-1.26-.37-1.88l1.85-3.19c.34-.62 1.11-.9 1.79-.63l1.81.73c.26-.17.52-.32.78-.46l.27-1.91c.09-.7.71-1.25 1.44-1.25h3.7c.74 0 1.36.54 1.45 1.27l.27 1.89c.27.14.53.29.79.46l1.8-.72c.71-.26 1.48.03 1.82.65l1.84 3.18c.36.66.2 1.44-.36 1.88l-1.52 1.19c.01.15.02.3.02.46s-.01.31-.02.46l1.52 1.19c.56.45.72 1.23.37 1.86l-1.86 3.22c-.34.62-1.11.9-1.8.63l-1.8-.72c-.26.17-.52.32-.78.46l-.27 1.91c-.1.68-.72 1.22-1.46 1.22zm-3.23-2h2.76l.37-2.55.53-.22c.44-.18.88-.44 1.34-.78l.45-.34 2.38.96 1.38-2.4-2.03-1.58.07-.56c.03-.26.06-.51.06-.78s-.03-.53-.06-.78l-.07-.56 2.03-1.58-1.39-2.4-2.39.96-.45-.35c-.42-.32-.87-.58-1.33-.77l-.52-.22-.37-2.55h-2.76l-.37 2.55-.53.21c-.44.19-.88.44-1.34.79l-.45.33-2.38-.95-1.39 2.39 2.03 1.58-.07.56a7 7 0 0 0-.06.79c0 .26.02.53.06.78l.07.56-2.03 1.58 1.38 2.4 2.39-.96.45.35c.43.33.86.58 1.33.77l.53.22.38 2.55z"></path>
                                <circle cx="12" cy="12" r="3.5"></circle>
                            </svg>
                        </div>
                        <div class="dropdown icon">
                            <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="../assets/images/icon/avatar-base.svg" width="25px" alt="">
                            </a>

                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <div class="avatar">
                                    <img src="../assets/images/icon/avatar-base.svg" width="25px" alt="">
                                </div>
                                <div class="detail">
                                    <div class="name"><?php echo $_SESSION['user']['userName'] . " " . $_SESSION['user']['userSurname'] ?></div>
                                    <div class="email"><?php echo $_SESSION['user']['userEmail']; ?></div>
                                </div>
                                <div class="mobil">
                                    <div class="supoort" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Destek">
                                        <svg class="t7" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="#000000" focusable="false">
                                            <path fill="none" d="M0 0h24v24H0z"></path>
                                            <path d="M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"></path>
                                        </svg>
                                        <span>Destek</span>
                                    </div>
                                    <div class="setting" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ayarlar">
                                        <svg class="Xy" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path d="M13.85 22.25h-3.7c-.74 0-1.36-.54-1.45-1.27l-.27-1.89c-.27-.14-.53-.29-.79-.46l-1.8.72c-.7.26-1.47-.03-1.81-.65L2.2 15.53c-.35-.66-.2-1.44.36-1.88l1.53-1.19c-.01-.15-.02-.3-.02-.46 0-.15.01-.31.02-.46l-1.52-1.19c-.59-.45-.74-1.26-.37-1.88l1.85-3.19c.34-.62 1.11-.9 1.79-.63l1.81.73c.26-.17.52-.32.78-.46l.27-1.91c.09-.7.71-1.25 1.44-1.25h3.7c.74 0 1.36.54 1.45 1.27l.27 1.89c.27.14.53.29.79.46l1.8-.72c.71-.26 1.48.03 1.82.65l1.84 3.18c.36.66.2 1.44-.36 1.88l-1.52 1.19c.01.15.02.3.02.46s-.01.31-.02.46l1.52 1.19c.56.45.72 1.23.37 1.86l-1.86 3.22c-.34.62-1.11.9-1.8.63l-1.8-.72c-.26.17-.52.32-.78.46l-.27 1.91c-.1.68-.72 1.22-1.46 1.22zm-3.23-2h2.76l.37-2.55.53-.22c.44-.18.88-.44 1.34-.78l.45-.34 2.38.96 1.38-2.4-2.03-1.58.07-.56c.03-.26.06-.51.06-.78s-.03-.53-.06-.78l-.07-.56 2.03-1.58-1.39-2.4-2.39.96-.45-.35c-.42-.32-.87-.58-1.33-.77l-.52-.22-.37-2.55h-2.76l-.37 2.55-.53.21c-.44.19-.88.44-1.34.79l-.45.33-2.38-.95-1.39 2.39 2.03 1.58-.07.56a7 7 0 0 0-.06.79c0 .26.02.53.06.78l.07.56-2.03 1.58 1.38 2.4 2.39-.96.45.35c.43.33.86.58 1.33.77l.53.22.38 2.55z"></path>
                                            <circle cx="12" cy="12" r="3.5"></circle>
                                        </svg>
                                        <span>Ayarlar</span>
                                    </div>
                                </div>
                                <div class="newAccount">
                                    <a href="../accounts/sign-in">
                                        <div class="newAccountIcon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus" viewBox="0 0 16 16">
                                                <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                                                <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z" />
                                            </svg>
                                        </div>
                                        <span>Başka bir hesap ekle</span>
                                    </a>
                                </div>
                                <div class="log-out">
                                    <a href="../accounts/log-out" class="btn btn-custom">Oturumu kapat</a>
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        </header>

        <main class="mail-main">
            <section class="mail-menu" id="sectionMenu">
                <div class="newEmail">
                    <div class="icon new" id="send">
                        <img src="../assets/images/create_32dp.png" alt="">
                        <span>Yeni oluştur</span>
                    </div>
                </div>
                <a href="#inbox" class="inbox box mt-2" data-bs-toggle="tooltip" data-bs-placement="right" title="Gelen Kutusu">
                    <div class="content">
                        <div class="icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-inboxes" viewBox="0 0 16 16">
                                <path d="M4.98 1a.5.5 0 0 0-.39.188L1.54 5H6a.5.5 0 0 1 .5.5 1.5 1.5 0 0 0 3 0A.5.5 0 0 1 10 5h4.46l-3.05-3.812A.5.5 0 0 0 11.02 1H4.98zm9.954 5H10.45a2.5 2.5 0 0 1-4.9 0H1.066l.32 2.562A.5.5 0 0 0 1.884 9h12.234a.5.5 0 0 0 .496-.438L14.933 6zM3.809.563A1.5 1.5 0 0 1 4.981 0h6.038a1.5 1.5 0 0 1 1.172.563l3.7 4.625a.5.5 0 0 1 .105.374l-.39 3.124A1.5 1.5 0 0 1 14.117 10H1.883A1.5 1.5 0 0 1 .394 8.686l-.39-3.124a.5.5 0 0 1 .106-.374L3.81.563zM.125 11.17A.5.5 0 0 1 .5 11H6a.5.5 0 0 1 .5.5 1.5 1.5 0 0 0 3 0 .5.5 0 0 1 .5-.5h5.5a.5.5 0 0 1 .496.562l-.39 3.124A1.5 1.5 0 0 1 14.117 16H1.883a1.5 1.5 0 0 1-1.489-1.314l-.39-3.124a.5.5 0 0 1 .121-.393zm.941.83.32 2.562a.5.5 0 0 0 .497.438h12.234a.5.5 0 0 0 .496-.438l.32-2.562H10.45a2.5 2.5 0 0 1-4.9 0H1.066z" />
                            </svg>
                        </div>
                        <span>Gelen Kutusu</span>
                    </div>
                    <div class="notification">1</div>
                </a>
                <a href="#stars" class="stars box mt-3" data-bs-toggle="tooltip" data-bs-placement="right" title="Yıldızlı">
                    <div class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                            <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                        </svg>
                    </div>
                    <span>Yıldızlı</span>
                </a>
                <a href="#outbox" class="outbox box box mt-3" data-bs-toggle="tooltip" data-bs-placement="right" title="Gönderilmiş Postalar">
                    <div class="icon">
                        <img src="../assets/images/send_black.png" alt="">
                    </div>
                    <span>Gönderilmiş Postalar</span>
                </a>
            </section>
            <div class="mail-content">
                <header class="mail-content-header">
                    <div class="start">
                        <div class="choose" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Seçiniz">
                            <input type="checkbox">
                        </div>
                        <div class="refresh" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Yenile">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z" />
                                <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z" />
                            </svg>
                        </div>
                        <div class="dropdown more" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Diğer">
                            <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                    <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                </svg>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <li>Tümünü okundu olarak işraretle</li>
                                <div class="divrider"></div>
                                <li class="disable"><i>Daha fazla işlem için ileti seçin</i></li>
                            </ul>
                        </div>
                    </div>
                    <div class="end">
                        <div class="primary" data-bs-toggle="tooltip">
                            <div class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-inboxes" viewBox="0 0 16 16">
                                    <path d="M4.98 1a.5.5 0 0 0-.39.188L1.54 5H6a.5.5 0 0 1 .5.5 1.5 1.5 0 0 0 3 0A.5.5 0 0 1 10 5h4.46l-3.05-3.812A.5.5 0 0 0 11.02 1H4.98zm9.954 5H10.45a2.5 2.5 0 0 1-4.9 0H1.066l.32 2.562A.5.5 0 0 0 1.884 9h12.234a.5.5 0 0 0 .496-.438L14.933 6zM3.809.563A1.5 1.5 0 0 1 4.981 0h6.038a1.5 1.5 0 0 1 1.172.563l3.7 4.625a.5.5 0 0 1 .105.374l-.39 3.124A1.5 1.5 0 0 1 14.117 10H1.883A1.5 1.5 0 0 1 .394 8.686l-.39-3.124a.5.5 0 0 1 .106-.374L3.81.563zM.125 11.17A.5.5 0 0 1 .5 11H6a.5.5 0 0 1 .5.5 1.5 1.5 0 0 0 3 0 .5.5 0 0 1 .5-.5h5.5a.5.5 0 0 1 .496.562l-.39 3.124A1.5 1.5 0 0 1 14.117 16H1.883a1.5 1.5 0 0 1-1.489-1.314l-.39-3.124a.5.5 0 0 1 .121-.393zm.941.83.32 2.562a.5.5 0 0 0 .497.438h12.234a.5.5 0 0 0 .496-.438l.32-2.562H10.45a2.5 2.5 0 0 1-4.9 0H1.066z"></path>
                                </svg>
                            </div>
                            <span>Birincil</span>
                        </div>
                    </div>
                </header>
                <div id="inbox" class="inbox-content tab-contant">
                    <div class="mail" id="mail">
                        <div class="choose" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Seç">
                            <input type="checkbox" id="choose" onclick="choose()">
                        </div>
                        <div class="star" id="mail-star">
                            <div class="icon star">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                                </svg>
                            </div>
                        </div>
                        <div class="name">Emirhan Kayabaş</div>
                        <div class="subject">Hesabınız Başarıyla Oluşturulmuştur</div><span class="nl">&nbsp;-&nbsp;</span>
                        <div class="body">Merhaba Emirhan. Kayıt olduğun için teşekkür ederiz.</div>
                        <div class="date">22:56</div>
                    </div>

                </div>
                <div id="stars" class="stars-content tab-contant">stars-content</div>
                <div id="outbox" class="outbox-content tab-contant">outbox-content</div>
            </div>
        </main>

        <div class="mobil-mail-button">
            <img src="../assets/images/create_32dp.png" alt="">
        </div>

        <?php require_once '../assets/include/Script.php' ?>
        <script>
            const searchInput = document.getElementById("searchInput");
            const result = document.getElementById("result");

            searchInput.addEventListener("focus", () => {
                //result.classList.add('focus');
                result.style.opacity = "1";
                result.style.visibility = "visible";
            });

            searchInput.addEventListener("blur", () => {
                //result.classList.remove('focus');
                result.style.opacity = "0";
                result.style.visibility = "hidden";
            });
        </script>
        <script>
            var tooltipTriggerList = [].slice.call(
                document.querySelectorAll('[data-bs-toggle="tooltip"]')
            );
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });

            let tab = $('.mail-main .mail-menu a');
            let content = $('.mail-main .mail-content .tab-contant');

            tab.filter(':first').addClass("active");
            content.filter(':not(:first)').hide();
            tab.click(function() {
                let id = $(this).attr('href');
                tab.removeClass("active");
                $(this).addClass("active");
                content.hide().filter(id).show();
            })

            function choose() {
                const choose = document.getElementById('choose');
                const mail = document.getElementById("mail");
                if (choose.checked == true) {
                    mail.classList.add("checked")
                } else {
                    mail.classList.remove("checked")
                }
            }

            const mailStar = document.getElementById('mail-star');

            mailStar.addEventListener("click", () => {
                mailStar.classList.toggle("active");
            })

            const menuOpen = document.getElementById("menuOpen");
            const sectionMenu = document.getElementById("sectionMenu");

            menuOpen.addEventListener("click", function(){
                sectionMenu.classList.toggle("close");
            })
        </script>
    </body>

    </html>
<?php
} else {
    header("Location: ../accounts/sign-up");
    die();
    exit();
}
?>